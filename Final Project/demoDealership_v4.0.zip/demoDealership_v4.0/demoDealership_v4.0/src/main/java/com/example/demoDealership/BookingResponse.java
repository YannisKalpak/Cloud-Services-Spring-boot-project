package com.example.demoDealership;

import java.time.LocalDate;
import java.time.LocalTime;

public class BookingResponse {
		
		private Integer id;
		private Integer customer_id;
		private Integer car_id;
		private LocalDate booking_date;
		private LocalTime booking_time;
		
		
		
		public BookingResponse(Integer id, Integer customer_id, Integer car_id, LocalDate date, LocalTime time) {
			this.id = id;
			this.customer_id = customer_id;
			this.car_id = car_id;
			this.booking_date = date;
			this.booking_time = time;
			
		}


		public Integer getId() {return id;}
		public void setId(Integer id) {this.id = id;}

		public LocalDate getDate() {return booking_date;}
		public void setDate(LocalDate date) {this.booking_date = date;}

		public LocalTime getTime() {return booking_time;}
		public void setTime(LocalTime time) {this.booking_time = time;}
		
		public Integer getCustomer_id() {return customer_id;}
		public void setCustomer_id(Integer customer_id) {this.customer_id = customer_id;}

		public Integer getCar_id() {return car_id;}
		public void setCar_id(Integer car_id) {this.car_id = car_id;}
		
}
