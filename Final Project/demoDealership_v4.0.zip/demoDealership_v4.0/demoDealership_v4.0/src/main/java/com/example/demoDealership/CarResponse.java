package com.example.demoDealership;

public class CarResponse {
	    private String brand;
	    private String model;
	    private String fuel;
	    private String engine;
	    private String moreinfo;
	    private int seats;
	    private int price;
	    private int Numofcars;
	    
	    // Constructor
	    public CarResponse(String brand, String model, String fuel, String engine, int seats, int price, String moreinfo, int Numofcars) {
	        this.brand = brand;
	        this.model = model;
	        this.fuel = fuel;
	        this.engine = engine;
	        this.seats = seats;
	        this.price = price;
	        this.moreinfo = moreinfo;
	        this.Numofcars = Numofcars;
	    }

	    // Getters and Setters
	    public String getBrand() {
	        return brand;
	    }

	    public void setBrand(String brand) {
	        this.brand = brand;
	    }

	    public String getModel() {
	        return model;
	    }

	    public void setModel(String model) {
	        this.model = model;
	    }

	    public String getFuel() {
	        return fuel;
	    }

	    public void setFuel(String fuel) {
	        this.fuel = fuel;
	    }

	    public String getEngine() {
	        return engine;
	    }

	    public void setEngine(String engine) {
	        this.engine = engine;
	    }
	    public String getInfo() {
	    	return moreinfo;
	    }
	    public void setInfo(String moreinfo) {
	    	this.moreinfo = moreinfo;
	    }

	    public int getSeats() {
	        return seats;
	    }

	    public void setSeats(int seats) {
	        this.seats = seats;
	    }

	    public int getPrice() {
	        return price;
	    }

	    public void setPrice(int price) {
	        this.price = price;
	    }

	    public int getNumOfCars() {
	        return Numofcars;
	    }

	    public void setNumOfCars(int Numofcars) {
	        this.Numofcars = Numofcars;
	    }
}