package com.example.demoDealership;

import org.springframework.data.jpa.repository.JpaRepository;

public interface BookingRepository extends JpaRepository<Bookings, Integer>{
  /////////////// 
  /*List<Bookings> findByCarIdAndBookingDate(Integer car_id, LocalDate booking_date);*/
	
/*@Query("SELECT b FROM Bookings b WHERE b.car.id = :carId AND b.booking_date = :bookingDate")
  List<Bookings> findByCarIdAndBookingDate(@Param("carId") Integer car_id, @Param("bookingDate") LocalDate booking_date);*/
}
