package com.example.demoDealership;

import java.util.*;
import java.util.stream.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

	

@Service
public class DealershipService {
     
	 @Autowired
	 private CarRepository CarRepository;

	 @Autowired
	 private DealershipRepository DealershipRepository;

	 public Dealership registerDealership(Dealership dealership) {
	       return DealershipRepository.save(dealership);
      }

	 public List<Car> getAllCars() throws Exception {
	     return CarRepository.findAll();
	 }
	 
	 public void addCar(Car c, String email) throws Exception {
		 // Find the dealership by the logged-in user's username
	     Dealership dealership = DealershipRepository.findByEmail(email);
	     if (dealership == null) {
	            throw new RuntimeException("Dealership not found");
	        }
	              //  .orElseThrow(() -> new RuntimeException("Dealership not found"));
		 Optional<Car> byId = CarRepository.findById(c.getId());
		 if(!byId.isPresent()) {
			 
			 c.setDealership(dealership);
			 CarRepository.save(c);
			 
		 }
		 else {
				Car updatedCar = byId.get();
				updatedCar.setNumOfCars(updatedCar.getNumOfCars() + c.getNumOfCars());
		        CarRepository.save(updatedCar);
			}
	 }

	 public void addDealership(Dealership d) throws Exception {
		  Optional<Dealership> byId = DealershipRepository.findById(d.getId());
		  if(!byId.isPresent())
			  DealershipRepository.save(d);
		 } 
	 
	 public List<Car> findByCriteria(String brand, String model, String fuel, String engine, Integer seats, Integer price) {
		    return CarRepository.findAll().stream()
		            .filter(car -> brand == null || car.getBrand().equalsIgnoreCase(brand))
		            .filter(car -> model == null || car.getModel().equalsIgnoreCase(model))
		            .filter(car -> fuel == null || car.getFuel().equalsIgnoreCase(fuel))
		            .filter(car -> engine == null || car.getEngine().equalsIgnoreCase(engine))
		            .filter(car -> seats == null || car.getSeats() == seats)
		            .filter(car -> (price == null || car.getPrice().equals(price)))
		            .collect(Collectors.toList());
		}

	//////////////
	 public Dealership authenticate(String email, String password) {
	        Optional<Dealership> dealership = Optional.of(DealershipRepository.findByEmail(email));
	        if (dealership.isPresent() && dealership.get().getPassword().equals(password)) {
	            return dealership.get(); // Authentication successful
	        }
	        return null; // Authentication failed
	    }

  ////////////
	 public boolean existsByIdOrEmail(Integer id, String email) {
		    return DealershipRepository.existsById(id) || DealershipRepository.existsByEmail(email);
		}



}
