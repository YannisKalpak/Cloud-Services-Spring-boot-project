package com.example.demoDealership;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CustomerService {
	   
	    @Autowired
	    private CustomerRepository customerRepository;
	    
	    @Autowired
	    private CarRepository CarRepository;
	
	    
	    public Customer getCustomer(Integer id) throws Exception {
			Optional<Customer> customerOptional = customerRepository.findById(id);
			
			if(customerOptional.isPresent() == false) {
				throw new Exception("Customer with ID " + id + " is not available.");
			}
			
			Customer customer = customerOptional.get();
			return customer;
		}
	    
	    
	    public Customer registerCustomer(Customer customer) {
	        return customerRepository.save(customer);
	    }
	    
	    public List<Car> getAllCars() throws Exception {
		     return CarRepository.findAll();}
	    
	    public List<Car> findByCriteria(String brand, String model, String fuel, String engine, Integer seats, Integer price) {
		    return CarRepository.findAll().stream()
		            .filter(car -> brand == null || car.getBrand().equalsIgnoreCase(brand))
		            .filter(car -> model == null || car.getModel().equalsIgnoreCase(model))
		            .filter(car -> fuel == null || car.getFuel().equalsIgnoreCase(fuel))
		            .filter(car -> engine == null || car.getEngine().equalsIgnoreCase(engine))
		            .filter(car -> seats == null || car.getSeats() == seats)
		            .filter(car -> (price == null || car.getPrice().equals(price)))
		            .collect(Collectors.toList());
		}
       
	     
	  //throws unhandled exceptions
		public Car checkCarAvailability (Integer car_id) throws Exception {
			Optional<Car> carOptional = CarRepository.findById(car_id);
			
			if(carOptional.isPresent() == false) {
				throw new Exception("Car with ID " + car_id + " is not found.");
			}
			
			Car car = carOptional.get();
			if(car.getNumOfCars() < 1) {
				throw new Exception("Car with ID " + car_id + " is not available.");
			}
			else return car;
		}
		
		public Car reduceNumberOfCars (Car car) {
			car.setNumOfCars(car.getNumOfCars()-1);
			return CarRepository.save(car);		
		}

		////////
	    public Customer authenticate(String email, String password) {
	        Optional<Customer> customer = Optional.of(customerRepository.findByEmail(email));
	        if (customer.isPresent() && customer.get().getEmail().equals(email) && customer.get().getPassword().equals(password)) {
	            return customer.get(); // Authentication successful
	        }
	        return null; // Authentication failed
	    } 
	    
	   /////// 
	    public boolean existsByIdOrEmail(Integer id, String email) {
	        return customerRepository.existsById(id) || customerRepository.existsByEmail(email);
	    }


  
}
