package com.example.demoDealership;

import java.util.*;
import java.util.stream.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

	

@Service
public class DealershipService {
     
	 @Autowired
	 private CarRepository CarRepository;
	 
	 @Autowired
	 private DealershipRepository DealershipRepository;
     
	 @Autowired
	 private DealershipRepository dealershipRepository;

	 public Dealership registerDealership(Dealership dealership) {
	     return dealershipRepository.save(dealership);
      }

	 public Dealership loginDealership(String dname, String password) {
	    Dealership dealership = dealershipRepository.findByDname(dname);
	      if (dealership != null && dealership.getPassword().equals(password)) {
	             return dealership;
	        }
	         throw new RuntimeException("Invalid credentials");
	     }
	 
	 public List<Car> getAllCars() throws Exception {
	     return CarRepository.findAll();
	 }
	
	 public Optional<Car> findCar(Integer c) throws Exception {
	     return CarRepository.findById(c);
	 }
    
	/* public List<Car> findByName(String name) {
	        return CarRepository.findByName(name);
	    }*/
	 
	 public void addCar(Car c) throws Exception {
		 Optional<Car> byId = CarRepository.findById(c.getId());
		 if(!byId.isPresent())
			 CarRepository.save(c);
	 }

	 public void addDealership(Dealership d) throws Exception {
		  Optional<Dealership> byId = DealershipRepository.findById(d.getId());
		  if(!byId.isPresent())
			  DealershipRepository.save(d);
		 } 
	 public List<Car> findByCriteria(String brand, String model, String fuel, String engine, Integer seats, Integer price) {
		    return CarRepository.findAll().stream()
		            .filter(car -> brand == null || car.getBrand().equalsIgnoreCase(brand))
		            .filter(car -> model == null || car.getModel().equalsIgnoreCase(model))
		            .filter(car -> fuel == null || car.getFuel().equalsIgnoreCase(fuel))
		            .filter(car -> engine == null || car.getEngine().equalsIgnoreCase(engine))
		            .filter(car -> seats == null || car.getSeats() == seats)
		            .filter(car -> price == null || car.getPrice() == price)
		            .collect(Collectors.toList());
		}
	 
	 










}
