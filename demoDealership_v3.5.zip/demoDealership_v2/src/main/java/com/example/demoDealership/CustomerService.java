package com.example.demoDealership;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CustomerService {
	   
	@Autowired
	    private CustomerRepository customerRepository;

	    public Customer registerCustomer(Customer customer) {
	        return customerRepository.save(customer);
	    }

	    public Customer loginCustomer(String email, String password) {
	        Customer customer = customerRepository.findByEmail(email);
	        if (customer != null && customer.getPassword().equals(password)) {
	            return customer;
	        }
	        throw new RuntimeException("Invalid credentials");
	    }
}
