package com.example.demoDealership;

import java.util.*;
import java.util.stream.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


@CrossOrigin(origins = "*", allowedHeaders = "*")

@RestController 
@RequestMapping("/home/dealerships")
public class DealershipController {
	 
	 @Autowired
	 private DealershipService ds;
	 
	  @PostMapping("/signup")
	  public Dealership registerDealership(@RequestBody Dealership dealership) {
	       return ds.registerDealership(dealership);
	    }

	  @PostMapping("/login")
	  public Dealership loginDealership(@RequestParam String dname, @RequestParam String password) {
	        return ds.loginDealership(dname, password);
	    }
	 
	 
	 @GetMapping(path = "/allCars")
	 public List<Car> getAllCar() throws Exception {
	     return ds.getAllCars();
	 }

	 @PostMapping(path = "/addCar")
	 public void addCar(@RequestBody Car c) throws Exception {
	            ds.addCar(c);
	 }

	 @GetMapping(path = "/cars/searchCar")
	 public List<CarResponse> searchCar(
	         @RequestParam(required = false) String brand,
	         @RequestParam(required = false) String model,
	         @RequestParam(required = false) String fuel,
	         @RequestParam(required = false) String engine,
	         @RequestParam(required = false) String info,
	         @RequestParam(required = false) Integer seats,
	         @RequestParam(required = false) Integer price) throws Exception {

	     // Search using a service method that handles the filtering logic
		return ds.findByCriteria(brand, model, fuel, engine, seats, price)
	             .stream()
	             .map(car -> new CarResponse(
	                     car.getBrand(),
	                     car.getModel(),
	                     car.getFuel(),
	                     car.getEngine(),
	                     car.getSeats(),
	                     car.getPrice(),
	                     car.getNumOfCars()))
	             .collect(Collectors.toList());
	 }
	 
}
