package com.example.demoDealership;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/home/customers")
public class CustomerController {

    @Autowired
    private CustomerService cs;

    @PostMapping("/signup")
    public Customer registerCustomer(@RequestBody Customer customer) {
        return cs.registerCustomer(customer);
    }

    @PostMapping("/login")
    public Customer loginCustomer(@RequestParam String email, @RequestParam String password) {
        return cs.loginCustomer(email, password);
    } 
}