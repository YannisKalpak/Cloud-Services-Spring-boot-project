package com.example.demoDealership;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Configuration;

@Configuration
public class DealershipConfig implements CommandLineRunner {

         @Autowired
		 private DealershipService ds;
		
		 @Override
		 public void run(String... args) throws Exception {
		     
		     Dealership d1 = new Dealership(12345678, "Opel", "opel@gmail.com", "pohTwbdfaWe");
		     ds.addDealership(d1);
		     Dealership d2 = new  Dealership(7683345, "Toyota", "toyota@gmail.com", "1234wsefdQ");
		     ds.addDealership(d2);
		     Dealership d3 = new  Dealership(998234, "Thomas Cars", "tomCars@gmail.com", "2wsx@WSX");
		     ds.addDealership(d3);
		
		   
		   /*  CarPurchase cp1 = new CarPurchase("2ssfasfw", 3); 
		     cp1.setDealership(d1);        
		     CarPurchase cp2 = new CarPurchase("khdowe231", 1);
		     cp2.setDealership(d3);
		     CarPurchase cp3 = new CarPurchase("98ihjwwd", 2);
		     cp3.setDealership(d1);
		     CarPurchase cp4 = new CarPurchase("gwgwfw213", 1);;
		     cp4.setDealership(d3);
		     CarPurchase cp5 = new CarPurchase("adwxww231", 4);
		     cp5.setDealership(d2); 
		
		     Car c1 = new Car("123124", "Opel", "Corsa", "Gas", "V8", 5, "In excellent condition", 20000, 6); 
		     c1.addSale(cp3);
		     ds.addCar(c1); */
		
		     System.out.println("DB has been created to DealershipService!!!");
		
		 }
}