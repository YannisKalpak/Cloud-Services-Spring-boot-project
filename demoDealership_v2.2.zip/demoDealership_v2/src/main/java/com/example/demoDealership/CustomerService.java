package com.example.demoDealership;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CustomerService {
	   
	@Autowired
	private CustomerRepository customerRepository;
	
	@Autowired
	private CarRepository CarRepository;

	    public Customer registerCustomer(Customer customer) {
	        return customerRepository.save(customer);
	    }

	    public Customer loginCustomer(String email, String password) {
	        Customer customer = customerRepository.findByEmail(email);
	        if (customer != null && customer.getPassword().equals(password)) {
	            return customer;
	        }
	        throw new RuntimeException("Invalid credentials");
	    }
	    public List<Car> getAllCars() throws Exception {
		     return CarRepository.findAll();
		 }
	    public List<Car> findByCriteria(String brand, String model, String fuel, String engine, Integer seats, Integer price) {
		    return CarRepository.findAll().stream()
		            .filter(car -> brand == null || car.getBrand().equalsIgnoreCase(brand))
		            .filter(car -> model == null || car.getModel().equalsIgnoreCase(model))
		            .filter(car -> fuel == null || car.getFuel().equalsIgnoreCase(fuel))
		            .filter(car -> engine == null || car.getEngine().equalsIgnoreCase(engine))
		            .filter(car -> seats == null || car.getSeats() == seats)
		            .filter(car -> price == null || car.getPrice() == price)
		            .collect(Collectors.toList());
		}
}
