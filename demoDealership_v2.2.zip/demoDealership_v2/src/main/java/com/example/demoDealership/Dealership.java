package com.example.demoDealership;

import javax.persistence.*;

@Entity 
@Table(name = "dealership")
public class Dealership {
   
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
	
	@Column(name = "dname", nullable = false)
	private String dname; 
	
	@Column(name = "email", nullable = false, unique = true)
	private String email;
   
    @Column(name = "password", nullable = false)
	private String password;

    public Dealership() {}

    public Dealership(Integer id ,String n,String e,String p) {
        this.id = id;
    	 dname = n;
         email = e; 
         password = p;
    }

    public Integer getId() {return id;}
    public String getName() {return dname;}
	public String getEmail() {return email;}
	public String getPassword() {return password;}

	
	public void setEmail(String email) {
		this.email = email;
	}
	public void setPassword(String password) {
		this.password = password;
	}

}
