package com.example.demoDealership;

import javax.persistence.*;

@Entity
public class Car {

	@Id
	private Integer id; 
	private String brand, model, fuel, engine, info;
	private Integer seats, price, numOfCars; 
	 
	 /* @ManyToOne(cascade = )
	  private Dealership dname;
	 
	 public Car() {
	    
		/* id = 0;
	     brand = "";
	     model = ""; 
	     fuel = ""; 
	     engine = "";
	     seats = 0;
	     moreInfo = "";
	     price = 0;
	     NumofCars = 0; 
	     
	 }*/
	
	//default constructor
		public Car(){}
	 
	 public Car(Integer id, String b, String m,String f,String e, String i,Integer s,Integer p,Integer NoC) {
	     this.id = id;
	     brand = b;
	     model = m; 
	     fuel = f; 
	     engine = e;
	     info = i;
	     seats = s;
	     price = p;
	     numOfCars = NoC; 
	     
	 }


	 /*public void addSale(CarPurchase cp) {
	     purchase.add(cp); // Προσθήκη της πώλησης στη λίστα πωλήσεων.
	     cp.addCar(this); // Ενημέρωση της αντίστροφης σχέσης στην οντότητα `Sale`.
	 }*/

	public Integer getId() {return id;}
	public String getBrand() {return brand;}
    public String getModel() {return model;}
	public String getFuel() {return fuel;}
	public String getEngine() {return engine;}
	public Integer getSeats() {return seats;}
	public String getInfo() {return info;}
	public Integer getPrice() {return price;}
	public Integer getNumOfCars() {return numOfCars;}
	
	 public void setBrand(String brand) {
	        this.brand = brand;
	    }
	 public void setModel(String model) {
	        this.model = model;
	    }
	
	 public void setFuel(String fuel) {
	        this.fuel = fuel;
	    }
	 public void setEngine(String engine) {
	        this.engine = engine;
	    }
	 public void setInfo(String info) {
	        this.info = info;
	    }
	 public void setSeats(int seats) {
	        this.seats = seats;
	    }
	 public void setPrice(int price) {
	        this.price = price;
	 }
	        
	 public void setNumOfCars(int numOfCars) {
	        this.numOfCars = numOfCars;
	    }
 




}
