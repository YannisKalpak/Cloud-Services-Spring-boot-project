package com.example.demoDealership;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/home")
public class HomeController {

    @GetMapping("/")
    public String home() {
        return "Welcome to the AutoDealership API! Please navigate to /home/customers or /home/dealerships to sign up or log in.";
    } 
}