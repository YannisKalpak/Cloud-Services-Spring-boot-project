package com.example.demoDealership;

import org.springframework.data.jpa.repository.JpaRepository;

public interface DealershipRepository extends JpaRepository <Dealership, Integer> {
	 Dealership findByDname(String dname);
}
