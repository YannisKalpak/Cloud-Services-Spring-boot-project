package com.example.demoDealership;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/home/customers")
public class CustomerController {

    @Autowired
    private CustomerService cs;

    @PostMapping("/signup")
    public Customer registerCustomer(@RequestBody Customer customer) {
        return cs.registerCustomer(customer);
    }

    @PostMapping("/login")
    public Customer loginCustomer(@RequestParam String email, @RequestParam String password) {
        return cs.loginCustomer(email, password);
    } 
    @GetMapping(path = "/allCars")
	 public List<Car> getAllCar() throws Exception {
	     return cs.getAllCars();
	 }
    @GetMapping(path = "/cars/searchCar")
	 public List<CarResponse> searchCar(
	         @RequestParam(required = false) String brand,
	         @RequestParam(required = false) String model,
	         @RequestParam(required = false) String fuel,
	         @RequestParam(required = false) String engine,
	         @RequestParam(required = false) Integer seats,
	         @RequestParam(required = false) Integer price) throws Exception {

	     // Search using a service method that handles the filtering logic
		return cs.findByCriteria(brand, model, fuel, engine, seats, price)
	             .stream()
	             .map(car -> new CarResponse(
	                     car.getBrand(),
	                     car.getModel(),
	                     car.getFuel(),
	                     car.getEngine(),
	                     car.getInfo(),
	                     car.getSeats(),
	                     car.getPrice(),
	                     car.getNumOfCars()))
	             .collect(Collectors.toList());
	 }
}