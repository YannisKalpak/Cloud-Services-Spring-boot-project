package com.example.demoDealership;

public class CarResponse {
    private String brand;
    private String model;
    private String fuel;
    private String engine;
    private String info;
    private int seats;
    private int price;
    private int numOfCars;

    // Constructor
    public CarResponse(String brand, String model, String fuel, String engine, String info, int seats, int price, int numOfCars) {
        this.brand = brand;
        this.model = model;
        this.fuel = fuel;
        this.engine = engine;
        this.info = info;
        this.seats = seats;
        this.price = price;
        this.numOfCars = numOfCars;
    }

    // Getters and Setters
    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getFuel() {
        return fuel;
    }

    public void setFuel(String fuel) {
        this.fuel = fuel;
    }

    public String getEngine() {
        return engine;
    }

    public void setEngine(String engine) {
        this.engine = engine;
    }
    public String getInfo() {
    	return info;
    }
    public void setInfo(String info) {
    	this.info = info;
    }

    public int getSeats() {
        return seats;
    }

    public void setSeats(int seats) {
        this.seats = seats;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getNumOfCars() {
        return numOfCars;
    }

    public void setNumOfCars(int numOfCars) {
        this.numOfCars = numOfCars;
    }
}