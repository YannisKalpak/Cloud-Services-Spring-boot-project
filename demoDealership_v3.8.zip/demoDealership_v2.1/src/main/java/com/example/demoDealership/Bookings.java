package com.example.demoDealership;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
@Table(name = "bookings")
public class Bookings {
	
	@Id
	@GeneratedValue
	private Integer id;
	
	@Column(name = "booking_date")
	private LocalDate booking_date;
	
	@Column(name = "booking_time")
	private LocalTime booking_time;
	
	//@JsonBackReference
	@ManyToOne
	@JoinColumn(name = "costumer_id", referencedColumnName = "id", nullable = false)
	private Customer customer;
	
	@JsonBackReference
	@ManyToOne
	@JoinColumn(name = "car_id", referencedColumnName = "id", nullable = false)
	private Car car;
	
	
	public Bookings() {
	}
	

	public Bookings(Customer customer, Car car, LocalDate date, LocalTime time) {
		this.booking_date = date;
		this.booking_time = time;
		this.customer = customer;
		this.car = car;
	}


	
	public Integer getId() {return id;}
    public void setId(Integer id) {this.id = id;}

	public LocalDate getDate() {return booking_date;}
	public void setDate(LocalDate date) {this.booking_date = date;}

	public LocalTime getTime() {return booking_time;}
	public void setTime(LocalTime time) {this.booking_time = time;}

	public Customer getCostumer() {return customer;}
    public void setCostumer(Customer costumer) {this.customer = costumer;}

	public Car getCar() {return car;}
	public void setCar(Car car) {this.car = car;}
}
	