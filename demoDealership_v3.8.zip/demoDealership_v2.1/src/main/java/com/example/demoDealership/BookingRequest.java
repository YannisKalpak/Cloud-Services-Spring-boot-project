package com.example.demoDealership;

import java.time.LocalDate;
import java.time.LocalTime;

public class BookingRequest {
	private Integer id;
	private LocalDate booking_date;
	private LocalTime booking_time;
	private Integer customer_id;
	private Integer car_id;
	

	public BookingRequest(Integer customer_id, Integer car_id, LocalDate date, LocalTime time) {
		this.customer_id = customer_id;
		this.car_id = car_id;
		this.booking_date = date;
		this.booking_time = time;
		
	}

	public LocalDate getDate() {return booking_date;}
	public void setDate(LocalDate date) {this.booking_date = date;}

	public LocalTime getTime() {return booking_time;}
	public void setTime(LocalTime time) {this.booking_time = time;}
	
	public Integer getCustomer_id() {return customer_id;}
	public void setCustomer_id(Integer customer_id) {this.customer_id = customer_id;}

	public Integer getCar_id() {return car_id;}
	public void setCar_id(Integer car_id) {this.car_id = car_id;}
	
	public Integer getId() {return id;}
	public void setId(Integer id) {this.id = id;}
	
}
	