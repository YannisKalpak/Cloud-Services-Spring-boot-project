package com.example.demoDealership;

import java.util.List;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity 
@Table(name = "dealership")
public class Dealership {
   
	@Id 
	@Column(name = "id", nullable = false, unique = true)
    private Integer id;
	
	@Column(name = "dname", nullable = false)
	private String dname; 
	
	@Column(name = "email", nullable = false, unique = true)
	private String email;
   
    @Column(name = "password", nullable = false)
	private String password;
  
    @JsonManagedReference
    @OneToMany(mappedBy="dealership",cascade = CascadeType.ALL,fetch = FetchType.LAZY)
	private List<Car> cars;
    
    
    public Dealership() {}

    public Dealership(Integer id ,String dn,String e,String p) {
        this.id = id;
    	 dname = dn;
         email = e; 
         password = p;
    }

    public Integer getId() {return id;}
    public String getDName() {return dname;}
	public String getEmail() {return email;}
	public String getPassword() {return password;}

	
	public void setEmail(String email) {
		this.email = email;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	public void setId(Integer id) {
		this.id = id;
	}

	public void setDname(String dname) {
		this.dname = dname;
	}
	public List<Car> getCars() { return cars; }
	
    public void setCars(List<Car> cars) { this.cars = cars; }

}
