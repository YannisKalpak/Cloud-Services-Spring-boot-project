package com.example.demoDealership;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BuyCarService {

    @Autowired
    private CarRepository carRepository;

    @Autowired
    private CustomerRepository customerRepository;

 
    public void processPurchase(Integer customerId, Integer carId) throws Exception {
        // Step 1: Validate customer existence
        Optional<Customer> customerOptional = customerRepository.findById(customerId);
        if (!customerOptional.isPresent()) {
            throw new Exception("Customer with ID " + customerId + " not found.");
        }

        // Step 2: Validate car existence
        Optional<Car> carOptional = carRepository.findById(carId);
        if (!carOptional.isPresent()) {
            throw new Exception("Car with ID " + carId + " not found.");
        }

        Car car = carOptional.get();

        // Step 3: Check car availability
        if (car.getNumOfCars() <= 0) {
            throw new Exception("Car with ID " + carId + " is out of stock.");
        }

        // Step 4: Reduce the number of cars available
        car.setNumOfCars(car.getNumOfCars() - 1);
        carRepository.save(car);

        // Step 5: Notify success
        System.out.println("Purchase successful: Customer " + customerId + " bought car " + carId);
    }
}