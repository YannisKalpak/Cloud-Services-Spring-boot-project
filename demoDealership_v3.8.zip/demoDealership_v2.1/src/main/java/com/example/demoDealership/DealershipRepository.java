package com.example.demoDealership;

//import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

public interface DealershipRepository extends JpaRepository <Dealership, Integer> {
	     Dealership findByEmail(String email);
         
	       ////////// 
	       boolean existsById(Integer id);

			boolean existsByEmail(String email);
}
