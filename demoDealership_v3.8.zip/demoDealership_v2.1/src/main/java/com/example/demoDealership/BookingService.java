package com.example.demoDealership;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BookingService {

	@Autowired
	private BookingRepository bookingRepository;
	
	@Autowired
    private CustomerService cs;
   
	
	/*@Autowired
	private CustomerRepository customerRepository;

	@Autowired
	private CarRepository carRepository;*/

	
	
	public BookingResponse createBooking(BookingRequest bookingRequest) throws Exception {
		Integer car_id = bookingRequest.getCar_id();
		Integer customer_id = bookingRequest.getCustomer_id();
		LocalDate booking_date = bookingRequest.getDate();
	    LocalTime booking_time = bookingRequest.getTime();
	    Customer customer = cs.getCustomer(customer_id);
	    
	    Car car = cs.checkCarAvailability(car_id);
	    
	    if (!checkBookingAvailability(booking_date,booking_time)) {
	    	throw new Exception("There is already a Booking for the chosen Date and Time.");
	    }
	    else {
	    	Car updatedCar = cs.reduceNumberOfCars(car);
			Bookings booking = bookingRepository.save(new Bookings(customer, updatedCar, booking_date, booking_time));
			return new BookingResponse(
					booking.getId(), booking_date, booking_time, customer_id, car_id);
		}
		
	}
	
	public boolean checkBookingAvailability(LocalDate date, LocalTime time) throws Exception{
		List<Bookings> existingBookings = getAllBookings();
		
	    for (Bookings existingBooking : existingBookings) {
	        if (existingBooking.getDate().isEqual(date) &&
	        	existingBooking.getTime().equals(time)) {
	              return false;
	        }
	    }
        return true;
	}
	
	public List<Bookings> getAllBookings() {
	     return bookingRepository.findAll();}
	
	/*public BookingResponse createBooking(BookingRequest bookingRequest) throws Exception {
    Integer customer_id = bookingRequest.getCustomer_id();
    Integer car_id = bookingRequest.getCar_id();

    // Validate customer
    Customer customer = customerRepository.findById(customer_id)
        .orElseThrow(() -> new Exception("Customer not found"));

    // Validate car availability
    Car car = carRepository.findById(car_id)
        .orElseThrow(() -> new Exception("Car not found"));
    if (car.getNumOfCars() <= 0) {
        throw new Exception("Car is not available for booking");
    }

    // Check booking availability
    if (!isBookingAvailable(bookingRequest.getDate(), bookingRequest.getTime(), car_id)) {
        throw new Exception("This time slot is already booked for the selected car");
    }

    // Create booking
    Bookings booking = new Bookings(customer, car, bookingRequest.getDate(), bookingRequest.getTime());
    bookingRepository.save(booking);

    // Update car availability
    car.setNumOfCars(car.getNumOfCars() - 1);
    carRepository.save(car);

    return new BookingResponse(booking.getId(), bookingRequest.getDate(), bookingRequest.getTime(), customer_id, car_id);
}

  public boolean isBookingAvailable(LocalDate date, LocalTime time, Integer car_id) {
     List<Bookings> existingBookings = bookingRepository.findByCarIdAndBookingDate(car_id, date);
     return existingBookings.stream().noneMatch(b -> b.getTime().equals(time));
}

 public List<Bookings> getAllBookings() {
     return bookingRepository.findAll();
 }
*/
}
