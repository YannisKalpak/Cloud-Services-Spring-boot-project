package com.example.demoDealership;

import java.util.List;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Table(name = "car")
public class Car {

	@Id
	@Column(name = "id", nullable = false, unique = true)
	private Integer id; 
	
	private String brand, model, fuel, engine, moreinfo;
	private Integer seats, price, Numofcars; 
	
	@JsonManagedReference
	@OneToMany(mappedBy = "car")
    private List<Bookings> bookings;
	
	@JsonBackReference
	@ManyToOne(cascade = CascadeType.ALL,fetch = FetchType.LAZY)
    @JoinColumn(name = "dealership_id", referencedColumnName = "id", nullable = true)
    private Dealership dealership;
	
	//default constructor
	public Car(){}
	 
	 public Car(Integer id, String b, String m,String f,String e,Integer s,Integer p,String i,Integer NoC) {
	     this.id = id;
	     brand = b;
	     model = m; 
	     fuel = f; 
	     engine = e;
	     seats = s;
	     price = p;
	     moreinfo = i;
	     Numofcars = NoC;  
	 }

	public Integer getId() {return id;}
	public String getBrand() {return brand;}
    public String getModel() {return model;}
	public String getFuel() {return fuel;}
	public String getEngine() {return engine;}
	public String getInfo() {return moreinfo;}
	public Integer getSeats() {return seats;}
	public Integer getPrice() {return price;}
	public Integer getNumOfCars() {return Numofcars;}
	
	 public void setBrand(String brand) {
	        this.brand = brand;
	    }
	 public void setModel(String model) {
	        this.model = model;
	    }
	
	 public void setFuel(String fuel) {
	        this.fuel = fuel;
	    }
	 public void setEngine(String engine) {
	        this.engine = engine;
	    }
	 public void setInfo(String info) {
	        this.moreinfo = info;
	    }

	public void setSeats(int seats) {
	        this.seats = seats;
	    }
	 public void setPrice(int price) {
	        this.price = price;
	 }
	        
	 public void setNumOfCars(int Numofcars) {
	        this.Numofcars = Numofcars;
	    }
	 
	 public Dealership getDealership() {
			return dealership;
		}

		public void setDealership(Dealership dealership) {
			this.dealership = dealership;
		}
	
	 public List<Bookings> getBookings() {return bookings;}
		public void setBookings(List<Bookings> bookings) {this.bookings = bookings;}
 
}
