package com.example.demoDealership;

import java.util.List;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity 
@Table(name = "customer")
public class Customer {
   
	@Id
	@Column(name = "id", nullable = false, unique = true)
    private Integer id;
	
	@Column(name = "name", nullable = false)
	private String name;
   
	@Column(name = "lastname", nullable = false)
	private String lastname;
    
	@Column(name = "email", nullable = false, unique = true)
	private String email;
	
	@Column(name = "password", nullable = false)
	private String password;
	
	//@JsonManagedReference
	@OneToMany(mappedBy = "customer" , cascade = CascadeType.ALL,fetch = FetchType.LAZY)
	private List<Bookings> bookings;

    public Customer(){}
    
	public Customer(Integer id ,String n,String l,String e,String p) {
        this.id = id;
    	 name = n;
         lastname = l;
    	 email = e; 
         password = p;
    }
    
    
	public Integer getId() {return id;}
	public String getName() {return name;}
	public String getLastname() {return lastname;}
	public String getEmail() {return email;}
	public String getPassword() {return password;}
	
	public void setPassword(String password) {
		this.password = password;
	}
}
