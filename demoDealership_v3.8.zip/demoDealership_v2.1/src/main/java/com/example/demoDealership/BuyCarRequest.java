package com.example.demoDealership;

public class BuyCarRequest {
    private int car_id; 
    private int customer_id;

	public int getCar_id() {
		return car_id;
	}
	
	public void setCar_id(int car_id) {
		this.car_id = car_id;
	}
	
	public int getCustomer_id() {
		return customer_id;
	}

	public void setCustomer_id(int customer_id) {
		this.customer_id = customer_id;
	}


}
