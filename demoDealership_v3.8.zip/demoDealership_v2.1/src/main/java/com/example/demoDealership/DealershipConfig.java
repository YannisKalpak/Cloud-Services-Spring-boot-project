package com.example.demoDealership;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Configuration;

@Configuration
public class DealershipConfig implements CommandLineRunner {

         @Autowired
		 private DealershipService ds;
		
		 @Override
		 public void run(String... args) throws Exception {
		     
		     Dealership d1 = new Dealership(12345678, "Opel", "opel@gmail.com", "pohTwbdfaWe");
		     ds.addDealership(d1);
		     Dealership d2 = new  Dealership(7683345, "Toyota", "toyota@gmail.com", "1234wsefdQ");
		     ds.addDealership(d2);
		     Dealership d3 = new  Dealership(998234, "Thomas Cars", "tomCars@gmail.com", "2wsx@WSX");
		     ds.addDealership(d3);
		 
		   
		     Car c1 = new Car(123, "Jaguar",  "performance", "Diesel", "V8", 4, 4000, "Aneto", 1);
		     //c1.setDealership(d1);
		     ds.addCar(c1,"opel@gmail.com");
			 Car c2 = new Car(444, "Ferrari",  "town", "Gasoline", "V12", 2, 8000, "Cool", 2);
			 //c2.setDealership(d3);
			 ds.addCar(c2,"toyota@gmail.com");
			 Car c3 = new Car(777, "Lamborgini", "urus", "Electricity", "V6", 4, 10000, "Big", 1);
			 //c3.setDealership(d2);
			 ds.addCar(c3,"tomCars@gmail.com");
			
			
			 
		     System.out.println("DB has been created to DealershipService!!!");
		
		 }
}