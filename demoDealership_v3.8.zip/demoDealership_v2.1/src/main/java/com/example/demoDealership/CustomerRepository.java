package com.example.demoDealership;

//import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

public interface CustomerRepository extends JpaRepository<Customer, Integer>{
	          Customer findByEmail(String email);
       
	        ////////
			boolean existsById(Integer id);

			boolean existsByEmail(String email);
              
}

