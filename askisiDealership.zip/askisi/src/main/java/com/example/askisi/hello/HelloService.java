package com.example.askisi.hello;

import java.util.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.*;

@Service
public class HelloService {
	
	@Autowired
	private CarRepository carRepository;
	@Autowired
	private DealershipRepository dealershipRepository;
	
	public void addCar(Car cr) throws Exception {
		Optional<Car> byId = carRepository.findById(cr.getName());
		if(!byId.isPresent())
			carRepository.save(cr);
	}
	
	public void addDealership(Dealership d) throws Exception {
		Optional<Dealership> byId = dealershipRepository.findById(d.getAfm());
		if(!byId.isPresent())
			dealershipRepository.save(d);
	}	

	public List<Car> getAllCars() {
		return carRepository.findAll();
	}
	
	 public List<Car> findByName(String name) {
	        return carRepository.findByName(name);
	    }
}
