package com.example.askisi.hello;

import java.util.*;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.*;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
public class HelloController {
	
	@Autowired
	private HelloService hs;
	
	@GetMapping(path="/cars")
	public List<Car> getAllCar()  throws Exception{
		return hs.getAllCars();
	} 
	
	@PostMapping(path="/addCar")
	public void addCar(@RequestBody Car cr) throws Exception {
		hs.addCar(cr);
	}
	
	@GetMapping(path="/cars/searchCar")
	public List<Car> searchCar(@RequestParam String name) throws Exception {
		return hs.findByName(name)
				.stream()
                .map(car -> new Car(car.getName(), car.getFuel(), car.getEngine(), car.getInfo(), car.getSeats(), car.getPrice(), car.getNumOfCars(), car.getDealership()))
                .collect(Collectors.toList());
	}

}
