package com.example.askisi.hello;

import org.springframework.boot.*;
import org.springframework.context.annotation.*;
import org.springframework.beans.factory.annotation.*;

@Configuration
public class HelloServiceConfig implements CommandLineRunner {
	
	@Autowired
	private HelloService hs;
	
	@Override
	public void run(String... args) throws Exception {
		Dealership d1 = new Dealership("012345", "Mazda hools", "Tasos", "tasos123");
		hs.addDealership(d1);
		Dealership d2 = new Dealership("67890", "BMW racers", "Nikos", "nikos456");
		hs.addDealership(d2);
		Dealership d3 = new Dealership("11111", "Toyota family", "Kostas", "kostas789");
		hs.addDealership(d3);
	
		
		Car c1 = new Car("Jaguar derma", "Diesel", "V8", "Aneto", 4, 4000, 1, d1);
		hs.addCar(c1);
		
		Car c2 = new Car("Ferrari town", "Gasoline", "V12", "Cool", 2, 8000, 2, d2);
		hs.addCar(c2);
		
		Car c3 = new Car("Lamborgini urus", "Electricity", "V6", "Big", 4, 10000, 1, d3);
		hs.addCar(c3);
	}

}
