package com.example.askisi.hello;

import java.util.*;
import javax.persistence.*;

@Entity
public class Car {
	@Id
	private String name;
	private String fuel, engine, info;
	private int seats, price, numOfCars;
	
	 @ManyToOne(cascade = CascadeType.ALL) // Assuming one dealership can have many cars
	 @JoinColumn(name = "dealership_name")
	 private Dealership dealership;
	
	//default constructor
	public Car(){}

	public Car(String n, String f, String e, String i, int s, int p, int num, Dealership d) {
		name = n;
		fuel = f;
		engine = e;
		info = i;
		seats = s;
		price = p;
		numOfCars = num;
		dealership = d;
	}

	public String getName() {return name;}
	public String getFuel() {return fuel;}
	public String getEngine() {return engine;}
	public String getInfo() {return info;}
	public int getSeats() {return seats;}
	public int getPrice() {return price;}
	public int getNumOfCars() {return numOfCars;}
	public Dealership getDealership() {return dealership;}
	
	 public void setName(String name) {
	        this.name = name;
	    }
	 public void setFuel(String fuel) {
	        this.fuel = fuel;
	    }
	 public void setEngine(String engine) {
	        this.engine = engine;
	    }
	 public void setInfo(String info) {
	        this.info = info;
	    }
	 public void setSeats(int seats) {
	        this.seats = seats;
	    }
	 public void setPrice(int price) {
	        this.price = price;
	 }
	        
	 public void setNumOfCars(int numOfCars) {
	        this.numOfCars = numOfCars;
	    }

	 public void setDealership(Dealership dealership) {
	        this.dealership = dealership;
	    }
}
