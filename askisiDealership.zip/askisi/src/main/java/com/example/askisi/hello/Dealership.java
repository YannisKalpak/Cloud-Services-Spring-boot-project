package com.example.askisi.hello;

import java.util.*;
import javax.persistence.*;

@Entity
public class Dealership {

	@Id
	private String name;
	private String afm;
	private String owner;
	private String password;
	
	
	public Dealership() {}
	
	public Dealership(String a, String n, String o, String p) {
		afm = a;
		name = n;
		owner = o;
		password = p;
	}
	
	public String getAfm() {return afm;}
	public String getName() {return name;}
	public String getOwner() {return owner;}
	public String getPassword() {return password;}
	
	public void setName(String name) {
        this.name = name;
    }
	public void setAfm(String afm) {
        this.afm = afm;
    }
	public void setOwner(String owner) {
        this.owner = owner;
    }
	public void setPassword(String password) {
        this.password = password;
    }
}
